document.querySelector('#rock').addEventListener('click', rpsGameExecute.bind(null, 'rock'));
document.querySelector('#paper').addEventListener('click', rpsGameExecute.bind(null, 'paper'));
document.querySelector('#scissors').addEventListener('click', rpsGameExecute.bind(null, 'scissors'));
document.querySelector('#resetstat').addEventListener('click', rpsResetStatistic);

let rpsGame = {
    'played': 0,
    'wins': 0,
    'draws': 0,
    'losses': 0,
    'winpercentage': 0.00
    
}

let Player = {
    HUMAN: 0,
    NEITHER: 1,
    BOT: 2
}

let bothPickElements = [];

function rpsClearElements() {
    for (let i = 0; i < bothPickElements.length; i++) {
        bothPickElements[i].remove();
    }
}

function rpsGameExecute(valasztott) {
    let yourPick = valasztott;
    let botPick = botPickRandom();
    result = getWinner(yourPick, botPick);
    updateScore(result);
}

function botPickRandom() {
    return ['rock', 'paper', 'scissors'][generateRandomNumber(0, 3)];
}

function generateRandomNumber(lowest, highest) {
    return Math.floor(Math.random() * highest) + lowest;
}

function getWinner(yourChoice, botChoice) {
    let rpsPoints = {
        'rock': { 'scissors': 1, 'rock': 0.5, 'paper': 0 },
        'paper': { 'rock': 1, 'paper': 0.5, 'scissors': 0 },
        'scissors': { 'paper': 1, 'scissors': 0.5, 'rock': 0}
    }

    return rpsPoints[yourChoice][botChoice] === rpsPoints[botChoice][yourChoice] ?
        Player.NEITHER : rpsPoints[yourChoice][botChoice] > rpsPoints[botChoice][yourChoice] ? Player.HUMAN : Player.BOT;
}

function updateScore(result) {
    switch (result) {
        case Player.HUMAN:
            rpsGame['wins']++;
            document.getElementById('wins').textContent = rpsGame['wins'];
            break;
        case Player.NEITHER:
            rpsGame['draws']++;
            document.getElementById('draws').textContent = rpsGame['draws'];
            break;
        default: 
            rpsGame['losses']++;
            document.getElementById('losses').textContent = rpsGame['losses'];
            break;
    }
    rpsGame['played']++;
    if (rpsGame['wins'] != 0) {
        rpsGame['winpercentage'] = rpsGame['wins'] / (rpsGame['played'] - rpsGame['draws']) * 100;
    }

    document.getElementById('played').textContent = rpsGame['played'];
    document.getElementById('winpercentage').textContent = rpsGame['winpercentage'].toFixed(2) + '%';
}


function rpsResetStatistic() {
    rpsGame['played'] = 0;
    rpsGame['wins'] = 0;
    rpsGame['draws'] = 0;
    rpsGame['losses'] = 0;
    rpsGame['winpercentage'] = 0.00;

    rpsClearElements();

    document.getElementById('played').textContent = rpsGame['played'];
    document.getElementById('wins').textContent = rpsGame['wins'];
    document.getElementById('draws').textContent = rpsGame['draws'];
    document.getElementById('losses').textContent = rpsGame['losses'];
    document.getElementById('winpercentage').textContent = rpsGame['winpercentage'].toFixed(2) + '%';
}