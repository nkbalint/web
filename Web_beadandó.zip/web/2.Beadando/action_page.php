<?php 
    function getColor($email)
    {
        $conn = mysqli_connect("localhost", "phpmyadmin", "K.Anita2000");
        if (!$conn)
        {
            echo 'Adatbázis hiba!';
            die("vége");
        }
        mysqli_select_db($conn, "adatok");
        $result = mysqli_query($conn, "SELECT * FROM tabla WHERE Username = '".$email."'"); 
        
        if (mysqli_num_rows($result) > 0) {           

            while($row = $result->fetch_assoc()) 
            {               
                mysqli_close($conn); 
                return $row['Titkos'];
            }

        } 
        
        else {
            echo "A felhasználó nem található az adatbázisban!";
        }          
        mysqli_close($conn);   
        return null; 
    }
   

    $root = "/home/anita/Dokumentumok/password.txt";
    $file = fopen($root, "r");
    $keys = array(5, -14, 31, -9, 3);
    $un_pw = array();
    while(!feof($file))
    {
        $line = fgets($file);
        $karakteres = $line;
        

        for ($i = 0; $i < strlen($line); $i++)
        {            
            $ascii = ord($line[$i]);
            $decoded = chr($ascii - $keys[fmod($i,5)]);
            if ($ascii == 10)
            {
                break;
            }
            $line[$i] = $decoded; 
                     
        }
        //echo $line."<br>";
        $splitted = explode("*", $line);        
        $un_pw[$splitted[0]] = trim($splitted[1]);       

    }
    fclose($file);


    $username = $_POST['uname'];
    $password= $_POST['psw'];
    
    foreach ($un_pw as $email => $pw) {
        //echo $email." --> ".$pw."<br>";
        if (strcmp($email, $username) == 0)
        {
            if (strcmp($password, $pw) == 0)
            {
                //echo $email." --> ".$pw."<br>";     
                echo getColor($email);       
                exit();
            }
            else{
                echo "Hibás jelszó!";
                exit();
            }
        }
        
    }
    echo "Hibás felhasználó név!";    
?>

